.. _utils_module:

:mod:`kazoo.handlers.utils`
---------------------------

.. automodule:: kazoo.handlers.utils

Public API
++++++++++

    .. autofunction:: capture_exceptions
    .. autofunction:: wrap

Private API
+++++++++++

  .. autofunction:: create_socket_pair
  .. autofunction:: create_tcp_socket
