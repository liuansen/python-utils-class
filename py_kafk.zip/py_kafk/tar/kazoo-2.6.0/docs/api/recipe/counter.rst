.. _counter_module:

:mod:`kazoo.recipe.counter`
---------------------------

.. automodule:: kazoo.recipe.counter

.. versionadded:: 0.7
    The Counter class.

Public API
++++++++++

    .. autoclass:: Counter
        :members:

        .. automethod:: __init__
        .. automethod:: __add__
        .. automethod:: __sub__
