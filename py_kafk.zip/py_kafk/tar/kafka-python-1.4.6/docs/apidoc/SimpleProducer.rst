SimpleProducer
==============

.. autoclass:: kafka.producer.SimpleProducer
    :members:
    :show-inheritance:

.. autoclass:: kafka.producer.KeyedProducer
    :members:
    :show-inheritance:

.. automodule:: kafka.producer.base
    :members:
    :show-inheritance:
