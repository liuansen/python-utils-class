KafkaAdminClient
===========

.. autoclass:: kafka.admin.KafkaAdminClient
    :members:
