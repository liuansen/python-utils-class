
from .kafka_tools import main
main()
