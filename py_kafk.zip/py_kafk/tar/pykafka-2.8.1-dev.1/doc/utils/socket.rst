pykafka.utils.socket
====================

.. automodule:: pykafka.utils.socket
   :members:
