pykafka.utils.struct_helpers
============================

.. automodule:: pykafka.utils.struct_helpers
   :members:
