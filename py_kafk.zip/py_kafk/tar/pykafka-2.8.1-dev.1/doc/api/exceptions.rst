pykafka.exceptions
==================

.. automodule:: pykafka.exceptions
   :members:
