pykafka.simpleconsumer
======================

.. automodule:: pykafka.simpleconsumer
   :members:
